void Monitor_Heater();
int get_RPM();
void Toggle_Heater();
void Turn_Off_Fan();
void Turn_On_Fan();
void do_update_pwm(char) ;
void Increase_Speed();
void Decrease_Speed();
void Set_RPM_RGB(int rpm);

void Set_DC_RGB(int duty_cycle);
//void Set_RPM_RGB(int rpm);